package com.Patient.Patientdata;

import org.springframework.boot.SpringApplication;


import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientdataApplication.class, args);
	}

}
