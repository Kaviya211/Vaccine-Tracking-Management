import React from 'react'

function C1(props) {
    return (
        <div>{props.content}</div>
    )
}

export default C1