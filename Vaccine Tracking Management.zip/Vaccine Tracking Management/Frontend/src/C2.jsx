import React from 'react'

function C2() {
    return (
        <div>C2</div>
    )
}

export default C2